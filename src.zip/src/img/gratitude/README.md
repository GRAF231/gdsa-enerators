Placeholder images for gratitude gallery
